# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import sys
import os
import csv
class SzhousePipeline(object):
    def __init__(self):
         # csv文件的位置,无需事先创建
        store_file = os.path.dirname(__file__) + 'sz_zufang_house.csv'
        # 打开(创建)文件
        self.file = open(store_file, 'w',encoding='gb18030')
        # csv写法
        self.writer = csv.writer(self.file)
        self.writer.writerow(('小区名字', '地址','面积', '房型', '租金', '细节', '发布时间', '详细链接'))
    
    def process_item(self, item, spider):
        self.writer.writerow((item['house_name'], item['address'],item['mianji'], item['fangxing'],item['money'], item['detail'],item['fabuDate'], item['link']))
        return item
    
    def close_spider(self, spider):
        #关闭数据库
        #self.cursor.close()
        #self.connect.close()

        self.file.close()