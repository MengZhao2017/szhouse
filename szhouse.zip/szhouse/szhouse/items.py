# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class SzhouseItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    house_name = scrapy.Field() 
    address = scrapy.Field()
    mianji =  scrapy.Field()
    fangxing = scrapy.Field()
    fabuDate = scrapy.Field()
    detail = scrapy.Field()
    money = scrapy.Field()
    link = scrapy.Field()
    
    
